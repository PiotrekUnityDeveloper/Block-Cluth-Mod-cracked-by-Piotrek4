package caterpillow;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;

public class Range extends CommandBase {
   public int func_82362_a() {
      return 0;
   }

   public String func_71517_b() {
      return "clutchRange";
   }

   public String func_71518_a(ICommandSender sender) {
      return "§cUsage: /clutchRange <blocks delay>";
   }

   public List<String> func_71514_a() {
      ArrayList<String> aliases = new ArrayList();
      aliases.add("blockRange");
      aliases.add("blockrange");
      aliases.add("clutchrange");
      aliases.add("range");
      return aliases;
   }

   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
      if (args.length == 0) {
         sender.func_145747_a(new ChatComponentText("§cPlease add a range for blocks"));
      } else {
         Settings.range = Integer.parseInt(args[0]);
         sender.func_145747_a(new ChatComponentText("§aRange set to " + Settings.range));
      }

   }
}
