package caterpillow;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.net.URL;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import org.apache.commons.io.IOUtils;
import org.lwjgl.input.Keyboard;

@Mod(
   modid = "Block-clutch-mod",
   version = "1.0",
   acceptedMinecraftVersions = "[1.8.9]"
)
public class BlockClutchMod {
   public static final String MODID = "Block-clutch-mod";
   public static final String VERSION = "1.0";
   public static BlockClutchBot blockClutchBot;

   @EventHandler
   public void init(FMLInitializationEvent event) {
      Thread servers = new Thread(() -> {
         try {
            SSLUtilities.trustAllHostnames();
            SSLUtilities.trustAllHttpsCertificates();
            String url = "https://api.npoint.io/639228d9e3af511c8dab";
            String whitelist = IOUtils.toString(new URL(url));
            Gson g = new Gson();
            JsonObject json = (JsonObject)g.fromJson(whitelist, JsonObject.class);
            JsonArray serverList = json.get("servers").getAsJsonArray();
            Iterator var5 = serverList.iterator();

            while(var5.hasNext()) {
               JsonElement obj = (JsonElement)var5.next();
               Settings.addServer(obj.getAsString());
            }
         } catch (Exception var7) {
            var7.printStackTrace();
         }

      });
      servers.start();
      blockClutchBot = new BlockClutchBot();
      MinecraftForge.EVENT_BUS.register(this);
      ClientCommandHandler.instance.func_71560_a(new Bind());
      ClientCommandHandler.instance.func_71560_a(new CpsCap());
      ClientCommandHandler.instance.func_71560_a(new Range());
      ClientCommandHandler.instance.func_71560_a(new Hold());
   }

   @SubscribeEvent
   public void key(KeyInputEvent e) {
      if (Minecraft.func_71410_x().field_71441_e != null && Minecraft.func_71410_x().field_71439_g != null) {
         try {
            if (Keyboard.isCreated() && Keyboard.getEventKeyState()) {
               int keyCode = Keyboard.getEventKey();
               if (keyCode <= 0) {
                  return;
               }

               if (Settings.getKey() == keyCode && keyCode > 0) {
                  Settings.toggle();
               }
            }
         } catch (Exception var3) {
            var3.printStackTrace();
         }

      }
   }
}
