package caterpillow;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;

public class CpsCap extends CommandBase {
   public String func_71517_b() {
      return "cpscap";
   }

   public String func_71518_a(ICommandSender sender) {
      return "/cpscap <true/false>";
   }

   public int func_82362_a() {
      return 0;
   }

   public List<String> func_71514_a() {
      ArrayList<String> aliases = new ArrayList();
      aliases.add("cpscap");
      aliases.add("cpsCap");
      return aliases;
   }

   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
      if (args.length == 0) {
         sender.func_145747_a(new ChatComponentText("§cPlease specify a whether true or false"));
      } else {
         try {
            Settings.cpsCap = Boolean.parseBoolean(args[0]);
            sender.func_145747_a(new ChatComponentText("§aCps cap has been set to " + Settings.cpsCap));
         } catch (Exception var4) {
            sender.func_145747_a(new ChatComponentText("§cPlease use a valid value"));
         }
      }

   }
}
