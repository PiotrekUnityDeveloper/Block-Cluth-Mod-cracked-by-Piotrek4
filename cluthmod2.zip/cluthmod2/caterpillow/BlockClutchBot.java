package caterpillow;

import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSnow;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Post;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import org.lwjgl.input.Keyboard;

public class BlockClutchBot {
   protected Minecraft mc = Minecraft.func_71410_x();
   private float startYaw;
   private float startPitch;

   public void onEnable() {
      if (this.mc.func_147104_D() == null || this.canEnable()) {
         if (this.mc.field_71415_G) {
            System.out.println(Settings.getServers());
            this.startYaw = this.mc.field_71439_g.field_70177_z;
            this.startPitch = this.mc.field_71439_g.field_70125_A;
            MinecraftForge.EVENT_BUS.register(this);
         } else {
            Settings.setToggled(false);
         }

      }
   }

   private boolean canEnable() {
      Iterator var1 = Settings.getServers().iterator();

      String ip;
      do {
         if (!var1.hasNext()) {
            this.mc.field_71439_g.func_145747_a(new ChatComponentText("§2cracked by Piotrek4"));
            //Settings.setToggled(false);
            return true;
         }

         ip = (String)var1.next();
      } while(!this.mc.func_147104_D().field_78845_b.equalsIgnoreCase(ip));

      return true;
   }

   public void onDisable() {
      MinecraftForge.EVENT_BUS.unregister(this);
   }

   @SubscribeEvent
   public void onRender(Post event) {
      if (!Settings.cpsCap) {
         this.placeBlock(Settings.range, true, event.partialTicks);
      } else {
         this.placeBlock(Settings.range, false, event.partialTicks);
      }

   }

   @SubscribeEvent
   public void onTick(ClientTickEvent event) {
      if (Settings.cpsCap) {
         this.placeBlock(Settings.range, true);
      }

      if (Settings.hold && !Keyboard.isKeyDown(Settings.getKey())) {
         Settings.toggle();
      }

   }

   public boolean placeBlock(int range, boolean place, float partialTicks) {
      if (!this.isAirBlock(getBlock((new BlockPos(this.mc.field_71439_g)).func_177977_b()))) {
         return true;
      } else if (this.placeBlockSimple((new BlockPos(this.mc.field_71439_g)).func_177977_b(), place, partialTicks)) {
         return true;
      } else {
         int dist = 0;

         for(Object var5 = null; dist <= range; ++dist) {
            for(int blockDist = 0; dist != blockDist; ++blockDist) {
               for(int x = blockDist; x >= 0; --x) {
                  int z = blockDist - x;
                  int y = dist - blockDist;
                  if (this.placeBlockSimple((new BlockPos(this.mc.field_71439_g)).func_177979_c(y).func_177964_d(x).func_177985_f(z), place, partialTicks)) {
                     return true;
                  }

                  if (this.placeBlockSimple((new BlockPos(this.mc.field_71439_g)).func_177979_c(y).func_177964_d(x).func_177985_f(-z), place, partialTicks)) {
                     return true;
                  }

                  if (this.placeBlockSimple((new BlockPos(this.mc.field_71439_g)).func_177979_c(y).func_177964_d(-x).func_177985_f(z), place, partialTicks)) {
                     return true;
                  }

                  if (this.placeBlockSimple((new BlockPos(this.mc.field_71439_g)).func_177979_c(y).func_177964_d(-x).func_177985_f(-z), place, partialTicks)) {
                     return true;
                  }
               }
            }
         }

         return false;
      }
   }

   public boolean placeBlock(int range, boolean place) {
      if (!this.isAirBlock(getBlock((new BlockPos(this.mc.field_71439_g)).func_177977_b()))) {
         return true;
      } else if (this.placeBlockSimple((new BlockPos(this.mc.field_71439_g)).func_177977_b(), place)) {
         return true;
      } else {
         int dist = 0;

         for(Object var4 = null; dist <= range; ++dist) {
            for(int blockDist = 0; dist != blockDist; ++blockDist) {
               for(int x = blockDist; x >= 0; --x) {
                  int z = blockDist - x;
                  int y = dist - blockDist;
                  if (this.placeBlockSimple((new BlockPos(this.mc.field_71439_g)).func_177979_c(y).func_177964_d(x).func_177985_f(z), place)) {
                     return true;
                  }

                  if (this.placeBlockSimple((new BlockPos(this.mc.field_71439_g)).func_177979_c(y).func_177964_d(x).func_177985_f(-z), place)) {
                     return true;
                  }

                  if (this.placeBlockSimple((new BlockPos(this.mc.field_71439_g)).func_177979_c(y).func_177964_d(-x).func_177985_f(z), place)) {
                     return true;
                  }

                  if (this.placeBlockSimple((new BlockPos(this.mc.field_71439_g)).func_177979_c(y).func_177964_d(-x).func_177985_f(-z), place)) {
                     return true;
                  }
               }
            }
         }

         return false;
      }
   }

   public boolean isAirBlock(Block block) {
      if (block.func_149688_o().func_76222_j()) {
         return !(block instanceof BlockSnow) || !(block.func_149669_A() > 0.125D);
      } else {
         return false;
      }
   }

   public int getFirstHotBarSlotWithBlocks() {
      for(int i = 0; i < 9; ++i) {
         if (this.mc.field_71439_g.field_71071_by.func_70301_a(i) != null && this.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() instanceof ItemBlock) {
            return i;
         }
      }

      return 0;
   }

   public boolean placeBlockSimple(BlockPos pos, boolean place, float partialTicks) {
      if (!this.doesSlotHaveBlocks(this.mc.field_71439_g.field_71071_by.field_70461_c)) {
         this.mc.field_71439_g.field_71071_by.field_70461_c = this.getFirstHotBarSlotWithBlocks();
      }

      Minecraft mc = Minecraft.func_71410_x();
      Entity entity = this.mc.func_175606_aa();
      double d0 = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)partialTicks;
      double d1 = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)partialTicks;
      double d2 = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)partialTicks;
      Vec3 eyesPos = new Vec3(d0, d1 + (double)mc.field_71439_g.func_70047_e(), d2);
      EnumFacing[] var13 = EnumFacing.values();
      int var14 = var13.length;

      for(int var15 = 0; var15 < var14; ++var15) {
         EnumFacing side = var13[var15];
         if (!side.equals(EnumFacing.UP) && !side.equals(EnumFacing.DOWN)) {
            BlockPos neighbor = pos.func_177972_a(side);
            EnumFacing side2 = side.func_176734_d();
            if (getBlock(neighbor).func_176209_a(mc.field_71441_e.func_180495_p(neighbor), false)) {
               Vec3 hitVec = (new Vec3(neighbor)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e(new Vec3(side2.func_176730_m()));
               if (!(eyesPos.func_72436_e(hitVec) > 36.0D)) {
                  float[] angles = this.getRotations(neighbor, side2, partialTicks);
                  mc.func_175606_aa().field_70177_z = angles[0];
                  mc.func_175606_aa().field_70125_A = angles[1];
                  if (place) {
                     mc.field_71439_g.field_70177_z = angles[0];
                     mc.field_71439_g.field_70125_A = angles[1];
                     mc.field_71442_b.func_178890_a(mc.field_71439_g, mc.field_71441_e, mc.field_71439_g.func_71045_bC(), neighbor, side2, hitVec);
                     mc.field_71439_g.func_71038_i();
                  }

                  return true;
               }
            }
         }
      }

      return false;
   }

   public boolean doesSlotHaveBlocks(int slotToCheck) {
      return this.mc.field_71439_g.field_71071_by.func_70301_a(slotToCheck) != null && this.mc.field_71439_g.field_71071_by.func_70301_a(slotToCheck).func_77973_b() instanceof ItemBlock && this.mc.field_71439_g.field_71071_by.func_70301_a(slotToCheck).field_77994_a > 0;
   }

   public boolean canPlace(BlockPos pos) {
      Minecraft mc = Minecraft.func_71410_x();
      Vec3 eyesPos = new Vec3(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + (double)mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v);
      EnumFacing[] var4 = EnumFacing.values();
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         EnumFacing side = var4[var6];
         BlockPos neighbor = pos.func_177972_a(side);
         EnumFacing side2 = side.func_176734_d();
         Vec3 hitVec = (new Vec3(neighbor)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e(new Vec3(side2.func_176730_m()));
         if (!(eyesPos.func_72436_e(hitVec) > 36.0D)) {
            return true;
         }
      }

      return false;
   }

   public boolean placeBlockSimple(BlockPos pos, boolean place) {
      Minecraft mc = Minecraft.func_71410_x();
      Entity entity = this.mc.func_175606_aa();
      double d0 = entity.field_70165_t;
      double d1 = entity.field_70163_u;
      double d2 = entity.field_70161_v;
      Vec3 eyesPos = new Vec3(d0, d1 + (double)mc.field_71439_g.func_70047_e(), d2);
      EnumFacing[] var12 = EnumFacing.values();
      int var13 = var12.length;

      for(int var14 = 0; var14 < var13; ++var14) {
         EnumFacing side = var12[var14];
         if (!side.equals(EnumFacing.UP) && (!side.equals(EnumFacing.DOWN) || Keyboard.isKeyDown(mc.field_71474_y.field_74314_A.func_151463_i()))) {
            BlockPos neighbor = pos.func_177972_a(side);
            EnumFacing side2 = side.func_176734_d();
            if (getBlock(neighbor).func_176209_a(mc.field_71441_e.func_180495_p(neighbor), false)) {
               Vec3 hitVec = (new Vec3(neighbor)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e(new Vec3(side2.func_176730_m()));
               if (!(eyesPos.func_72436_e(hitVec) > 36.0D)) {
                  float[] angles = this.getRotations(neighbor, side2);
                  mc.func_175606_aa().field_70177_z = angles[0];
                  mc.func_175606_aa().field_70125_A = angles[1];
                  if (place) {
                     mc.field_71439_g.field_70177_z = angles[0];
                     mc.field_71439_g.field_70125_A = angles[1];
                     mc.field_71442_b.func_178890_a(mc.field_71439_g, mc.field_71441_e, mc.field_71439_g.func_71045_bC(), neighbor, side2, hitVec);
                     mc.field_71439_g.func_71038_i();
                  }

                  return true;
               }
            }
         }
      }

      return false;
   }

   public static Block getBlock(BlockPos pos) {
      return Minecraft.func_71410_x().field_71441_e.func_180495_p(pos).func_177230_c();
   }

   public float[] getRotations(BlockPos block, EnumFacing face, float partialTicks) {
      Entity entity = this.mc.func_175606_aa();
      double posX = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)partialTicks;
      double posY = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)partialTicks;
      double posZ = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)partialTicks;
      double x = (double)block.func_177958_n() + 0.5D - posX + (double)face.func_82601_c() / 2.0D;
      double z = (double)block.func_177952_p() + 0.5D - posZ + (double)face.func_82599_e() / 2.0D;
      double y = (double)block.func_177956_o() + 0.5D;
      double d1 = posY + (double)this.mc.field_71439_g.func_70047_e() - y;
      double d3 = (double)MathHelper.func_76133_a(x * x + z * z);
      float yaw = (float)(Math.atan2(z, x) * 180.0D / 3.141592653589793D) - 90.0F;
      float pitch = (float)(Math.atan2(d1, d3) * 180.0D / 3.141592653589793D);
      if (yaw < 0.0F) {
         yaw += 360.0F;
      }

      return new float[]{yaw, pitch};
   }

   public float[] getRotations(BlockPos block, EnumFacing face) {
      Entity entity = this.mc.func_175606_aa();
      double posX = entity.field_70165_t;
      double posY = entity.field_70163_u;
      double posZ = entity.field_70161_v;
      double x = (double)block.func_177958_n() + 0.5D - posX + (double)face.func_82601_c() / 2.0D;
      double z = (double)block.func_177952_p() + 0.5D - posZ + (double)face.func_82599_e() / 2.0D;
      double y = (double)block.func_177956_o() + 0.5D;
      double d1 = posY + (double)this.mc.field_71439_g.func_70047_e() - y;
      double d3 = (double)MathHelper.func_76133_a(x * x + z * z);
      float yaw = (float)(Math.atan2(z, x) * 180.0D / 3.141592653589793D) - 90.0F;
      float pitch = (float)(Math.atan2(d1, d3) * 180.0D / 3.141592653589793D);
      if (yaw < 0.0F) {
         yaw += 360.0F;
      }

      return new float[]{yaw, pitch};
   }
}
