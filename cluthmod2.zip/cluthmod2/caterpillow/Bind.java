package caterpillow;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.ChatComponentText;
import org.lwjgl.input.Keyboard;

public class Bind extends CommandBase {
   public String func_71517_b() {
      return "clutchBind";
   }

   public int func_82362_a() {
      return 0;
   }

   public String func_71518_a(ICommandSender sender) {
      return "§cUsage: /clutchBind <key>";
   }

   public List<String> func_71514_a() {
      ArrayList<String> aliases = new ArrayList();
      aliases.add("blockclutchbind");
      aliases.add("clutchbind");
      aliases.add("bind");
      return aliases;
   }

   public void func_71515_b(ICommandSender sender, String[] args) throws CommandException {
      if (args.length == 0) {
         sender.func_145747_a(new ChatComponentText("§cPlease specify a key"));
      } else {
         Settings.setKey(Keyboard.getKeyIndex(args[0].toUpperCase()));
         if (Settings.getKey() == 0) {
            sender.func_145747_a(new ChatComponentText("§cPlease use a valid key"));
         } else {
            sender.func_145747_a(new ChatComponentText("§aKey bound to " + Keyboard.getKeyName(Settings.getKey())));
         }
      }

   }
}
